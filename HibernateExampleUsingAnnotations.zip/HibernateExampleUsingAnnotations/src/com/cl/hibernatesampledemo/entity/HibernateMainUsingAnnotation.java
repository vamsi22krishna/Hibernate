package com.cl.hibernatesampledemo.entity;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cl.hibernatesampledemo.updates.HibernateRecordManipulation;

public class HibernateMainUsingAnnotation {
	public static void main(String[] args) {
		HibernateRecordManipulation hm = new HibernateRecordManipulation();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("Enter the options");
			System.out.println("insert:Insert the details of students");
			System.out.println("list:List the student details");
			System.out.println("delete:Delete all the student records");
			System.out.println("deleteByid:Delete student by id");
			System.out.println("exit:To Exit");
			String choice = sc.next();
			switch (choice) {
			case "insert":
				hm.createAndInsert();
				break;
			case "list":
				hm.listRecords();
				break;
			case "delete":
				hm.deleteAllRecords();
				break;
			case "deleteByid":
				hm.deleteById();
				break;
			case "exit":
				System.exit(0);
			default:
				System.out.println("Enter the correct value");
				break;

			}
		}

	}
}
