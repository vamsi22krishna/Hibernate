package com.cl.hibernatesampledemo.updates;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="insurance_details")

public class Insurence {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="insurance_id")
	private int insurenceId;
	@Column(name="insurance_name",nullable=false)
	private String insurenceName;
	@Column(name="insured_amt",nullable=false)
	private float insuredAmt;
	@Column(name="eligible_amt",nullable=false)
	private float elegibleAmt;
	public Insurence() {
		super();
		
	}
	public int getInsurenceId() {
		return insurenceId;
	}
	public void setInsurenceId(int insurenceId) {
		this.insurenceId = insurenceId;
	}
	public String getInsurenceName() {
		return insurenceName;
	}
	public void setInsurenceName(String insurenceName) {
		this.insurenceName = insurenceName;
	}
	public float getInsuredAmt() {
		return insuredAmt;
	}
	public void setInsuredAmt(float insuredAmt) {
		this.insuredAmt = insuredAmt;
	}
	public float getElegibleAmt() {
		return elegibleAmt;
	}
	public void setElegibleAmt(float elegibleAmt) {
		this.elegibleAmt = elegibleAmt;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(elegibleAmt);
		result = prime * result + Float.floatToIntBits(insuredAmt);
		result = prime * result + insurenceId;
		result = prime * result + ((insurenceName == null) ? 0 : insurenceName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Insurence other = (Insurence) obj;
		if (Float.floatToIntBits(elegibleAmt) != Float.floatToIntBits(other.elegibleAmt))
			return false;
		if (Float.floatToIntBits(insuredAmt) != Float.floatToIntBits(other.insuredAmt))
			return false;
		if (insurenceId != other.insurenceId)
			return false;
		if (insurenceName == null) {
			if (other.insurenceName != null)
				return false;
		} else if (!insurenceName.equals(other.insurenceName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Insurence [insurenceId=" + insurenceId + ", insurenceName=" + insurenceName + ", insuredAmt="
				+ insuredAmt + ", elegibleAmt=" + elegibleAmt + "]";
	}
	
	
	
	
	

}
