package com.cl.hibernatesampledemo.updates;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.cl.hibernatesampledemo.entity.HibernateUtil;
import com.cl.hibernatesampledemo.entity.StudentInfo;

public class HibernateRecordManipulation {

public static void deleteById() {
	try (Session session = HibernateUtil.getSessionFactory().openSession()) {
		Transaction tx= session.beginTransaction();
		int id = 1;
		Query deleteQuery = session.createQuery("delete from StudentInfo where studentId = :id");
		deleteQuery.setInteger("id", id);
		int rowCount = deleteQuery.executeUpdate();
		if(rowCount!=0){
			System.out.println("rows deleted = "+rowCount);
		}else{
			System.out.println("no rows found");
		}
		tx.commit();
}
}

public static void deleteAllRecords() {
	try(Session session=HibernateUtil.getSessionFactory().openSession()){
		Transaction tx=session.beginTransaction();
		Query deleteQuery=session.createQuery("delete from StudentInfo");
		int rowCount=deleteQuery.executeUpdate();
		if(rowCount!=0) {
			System.out.println("rows deleted="+rowCount);
			
		}else {
			System.out.println("no records found");
		}
		tx.commit();
	}
}

public static void listRecords() {
	//list all student data
	try(Session session=HibernateUtil.getSessionFactory().openSession()){
		Transaction tx=session.beginTransaction();
		List<StudentInfo> studentList= session.createQuery("from StudentInfo",StudentInfo.class).list();
		studentList.stream().forEach(System.out::println);
		
	
	}
}

public static void createAndInsert() {
	Transaction transaction=null;
	Session dbSession=null;
	Scanner sc=new Scanner(System.in);
	
	try {
		dbSession =HibernateUtil.getSessionFactory().openSession();
		StudentInfo st=new StudentInfo();
		System.out.println("Enter the student name");
		String name=sc.nextLine();
		System.out.println("Enter the student email");
		String emial=sc.nextLine();
		st.setStudentName(emial);
	//		Insurence is=new Insurence();
//		is.setInsurenceName("Krishna");
//		is.setInsuredAmt(100000);
//		is.setElegibleAmt(60000);
		transaction=dbSession.beginTransaction();
		dbSession.save(st);
		transaction.commit();
	}catch(Exception e) {
		e.printStackTrace();
	}finally {
		
	}
}
}
